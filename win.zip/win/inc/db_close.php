<?php
    mysqli_free_result($result);//for clean $result variable
    mysqli_close($conn);//for close databace
?>